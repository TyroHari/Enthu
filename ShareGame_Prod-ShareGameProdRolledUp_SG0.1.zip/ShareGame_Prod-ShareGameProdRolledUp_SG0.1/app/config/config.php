<?php
//DB connection details
define('DB_HOST','sql207.epizy.com');
define('DB_USER','epiz_22187056');
define('DB_PASS','harinish93');
define('DB_NAME','epiz_22187056_sharegame');

//Path config
define('PATHROOT',dirname(dirname(__FILE__)));
define('BASEURL','http://enthugalatta.epizy.com');

define('SITENAME','Share Games');

define('CATEGORY','Test');

//Session variables
define('USERNAME','username');
define('USERID','userid');
define('USERFRNDSCORE','score');
define('TOTALSCORE','totalscore');
define('QUIZFINSHED','gameover');