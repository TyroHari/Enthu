<?php require_once PATHROOT.'/views/inc/header.php'; ?>
<div class="jumbotron jumbotron-flud text-center">
    <div class="container">
        <h1><?php echo $data['title']; ?></h1>
        <hr>
    </div>
</div>
<?php require_once PATHROOT.'/views/inc/footer.php'; ?>