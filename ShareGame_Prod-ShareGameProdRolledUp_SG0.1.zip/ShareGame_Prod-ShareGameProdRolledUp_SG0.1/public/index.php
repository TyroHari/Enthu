<?php
    session_start();
    require_once '../app/bootstrap.php';
    new Core;